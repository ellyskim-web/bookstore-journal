import { fetchCurrentWeather } from '../../../lib/weather';

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const lat = searchParams.get('lat') || process.env.NEXT_PUBLIC_STORE_LAT;
    const lon = searchParams.get('lon') || process.env.NEXT_PUBLIC_STORE_LON;

    if (!lat || !lon) {
      return Response.json(
        { error: '위치 정보가 필요합니다.' },
        { status: 400 }
      );
    }

    const weather = await fetchCurrentWeather(lat, lon);
    return Response.json(weather);
  } catch (error) {
    console.error('날씨 API 오류:', error);
    return Response.json(
      { error: error.message || '날씨 정보를 가져올 수 없습니다.' },
      { status: 500 }
    );
  }
}
